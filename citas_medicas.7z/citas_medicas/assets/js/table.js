 $(document).ready(function() {
    $('#myTable2').DataTable();
} );