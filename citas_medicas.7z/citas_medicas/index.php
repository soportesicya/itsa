<?php 
//redireccionar a la vista de login

header('location: vista/page-login.php');
 ?>